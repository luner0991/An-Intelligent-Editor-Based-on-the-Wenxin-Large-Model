<template>
  <div class="EditMain" ref="filecont" @mousedown="notsee()" >
    <ul @mousedown="see()" v-show="visiblemenu" :style="{ left: position.left + 'px', top: position.top + 'px', display: (visiblemenu ? 'grid' : 'none') }" class="contextmenu">
        <div class="item"  @click="polish()">
            <el-icon><Brush /></el-icon>
            润色
        </div>
        <div class="item" @click="continuation()">
            <el-icon><EditPen /></el-icon>
            续写
        </div>
        <div class="item"  @click="translate()">
            <el-icon><ChatDotRound /></el-icon>
            翻译
        </div>
        <div class="item"  @click="Keyword_extraction()">
            <el-icon><Key /></el-icon>
            关键词提取
        </div>
        <div class="item"  @click="summary()">
            <el-icon><View /></el-icon>
            自动摘要
        </div>
        <div class="item"  @click="Sick_sentence_rewriting()">
            <el-icon><Checked /></el-icon>
            病句改写
        </div>
      
    </ul>
    <div class="lefttool">
    <input type="file" @change="handleFileChange" class="file-input" />
    <img :src="imageSrc"  class="image-preview" />
  </div>
    <div class="editor">
      <div class="editorcard" >
        <div class="toptools">
          <EditorMenu :editor="editor" />
        </div>
        <div class="editcont" >
          <EditorContent
          @scroll="hasscroll()"
          @mousedown="notsee()"
          @mousemove="mousemove()" 
          @mouseup="selecttext($event)"
          style="padding: 8px;  overflow-y: auto;"
          :editor="editor"
        />
        </div>
       
        <div class="bottomcount">
          字数统计:
          {{ editor?.storage.characterCount.characters() }}
        </div>
      </div>
    </div>
    
    <div class="righttools">
      <Outline></Outline>
    </div>
    
  </div>
  </template>
  <script lang="ts" setup>
  import {Brush,EditPen,ChatDotRound,Key,Checked,View} from '@element-plus/icons-vue'
  import { defineComponent, onMounted, onBeforeUnmount, ref,watch } from 'vue';
  import { Editor, EditorContent, useEditor, BubbleMenu  } from '@tiptap/vue-3';
  import { storeToRefs } from 'pinia'
  import Underline from '@tiptap/extension-underline'
  import Italic from '@tiptap/extension-italic'
  import TextAlign from '@tiptap/extension-text-align'
  import Highlight from '@tiptap/extension-highlight' 
  import hljs from 'highlight.js';
  import 'highlight.js/styles/default.css'; // 导入高亮样式

  // 列表
  import ListItem from '@tiptap/extension-list-item'
  import OrderedList from '@tiptap/extension-ordered-list'
  import BulletList from '@tiptap/extension-bullet-list'
  // 代码
  import CodeBlockLowlight from '@tiptap/extension-code-block-lowlight'
  import css from 'highlight.js/lib/languages/css'
  import js from 'highlight.js/lib/languages/javascript'
  import ts from 'highlight.js/lib/languages/typescript'
  import html from 'highlight.js/lib/languages/xml'
  import { common, createLowlight } from 'lowlight'
  // 字数统计
  import CharacterCount from '@tiptap/extension-character-count'
  import Heading from '@tiptap/extension-heading'
  import StarterKit from '@tiptap/starter-kit'
  import Placeholder from '@tiptap/extension-placeholder'
  import { UndoRound, MoreHorizOutlined } from '@vicons/material'
  import TaskItem from '@tiptap/extension-task-item'
  import TaskList from '@tiptap/extension-task-list'
  import Outline from './Outline/index.vue'
    // 使用Pinia
  import { useEditorStore } from '@/store'
  import EditorMenu from './EditorMenu/index.vue'
  import { defineStore } from 'pinia'
  import { ElMessage } from 'element-plus';


  const lowlight = createLowlight()
  lowlight.register({ html, ts, css, js })

    const aipolish = ref("")
    const filecont = ref(null);
    const aicontinuation = ref("")
    const aitranslate = ref("")
    const aiKeyword_extraction = ref("")
    const aisummary = ref("")
    const aiSick_sentence_rewriting = ref("")
    const visiblemenu = ref(false)
    const position = ref({
          top: 0,
          left: 0
    })
    const imageSrc = ref('');
    const file = ref<File>();
    var hasmove=ref(false);
    var hisstring:any;
    var selection:any;
    const handleFileChange = (event: Event) => {
      const target = event.target as HTMLInputElement;
      if (target.files && target.files[0]) {
        file.value = target.files[0];
        imageSrc.value = URL.createObjectURL(file.value);
      }
    };
    //进行润色的函数
  import axios from 'axios'
  const polish=()=>{
  visiblemenu.value = false;
  let formData = new FormData();
  formData.append("username","123456");
  formData.append("key","ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0");
  formData.append("cont",hisstring);
  let url = 'http://127.0.0.1:3389/getpolish' //访问后端接口的url
  let method = 'post'

  axios({
    method,
    url,
    data: formData,
  }).then(res => {
    alert(res.data.answer)
    console.log(res.data.answer);
  });
}

//进行ai续写
const continuation=()=>{
  //console.log("进入了")
  visiblemenu.value = false;
  let formData = new FormData();
  formData.append("username","123456");
  formData.append("key","ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0");
  formData.append("cont",hisstring);
  let url = 'http://127.0.0.1:3389/getcontinuation' //访问后端接口的url
  let method = 'post'
  axios({
    method,
    url,
    data: formData,
  }).then(res => {
    alert(res.data.answer)
    console.log(res.data.answer);
  });
}
//ai翻译
const translate=()=>{
  visiblemenu.value = false;
  let formData = new FormData();
  formData.append("username","123456");
  formData.append("key","ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0");
  formData.append("cont",hisstring);
  // input = hisstring
  let url = 'http://127.0.0.1:3389/gettranslation' //访问后端接口的url
  let method = 'post'
  axios({
    method,
    url,
    data: formData,
  }).then(res => {
    alert(res.data.answer)
    console.log(res.data.answer);
  });
  output = res.data.answer
  // input -> 
  
}

//进行ai关键词提取
const Keyword_extraction=()=>{
  visiblemenu.value = false;
  let formData = new FormData();
  formData.append("username","123456");
  formData.append("key","ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0");
  formData.append("cont",hisstring);
  let url = 'http://127.0.0.1:3389/getKeyword_extraction' //访问后端接口的url
  let method = 'post'
  axios({
    method,
    url,
    data: formData,
  }).then(res => {
    alert(res.data.answer)
    console.log(res.data.answer);
  });
}
//进行ai自动摘要
const summary=()=>{
  visiblemenu.value = false;
  let formData = new FormData();
  formData.append("username","123456");
  formData.append("key","ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0");
  formData.append("cont",hisstring);
  let url = 'http://127.0.0.1:3389/getsummary' //访问后端接口的url
  let method = 'post'
  axios({
    method,
    url,
    data: formData,
  }).then(res => {
    alert(res.data.answer)
    console.log(res.data.answer);
  });
}
//进行ai病句改写
const Sick_sentence_rewriting=()=>{
  visiblemenu.value = false;
  let formData = new FormData();
  formData.append("username","123456");
  formData.append("key","ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0");
  formData.append("cont",hisstring);
  let url = 'http://127.0.0.1:3389/getSick_sentence_rewriting' //访问后端接口的url
  let method = 'post'
  axios({
    method,
    url,
    data: formData,
  }).then(res => {
    alert(res.data.answer)
    console.log(res.data.answer);
  });
}

    // 获取选中的文字
    const selecttext= (e:MouseEvent)=>{
            selection = window.getSelection();
            if(selection!=null&&hisstring!=selection){
              var content = selection.toString();
              if(content!=""){
                  var rect = filecont.value.getBoundingClientRect();
                  visiblemenu.value = true
                  // alert(e.clientY)
                  // alert(e.clientX)
                  position.value.top =  e.clientY;
                  position.value.left =e.clientX;
                  hisstring=content
                }
              // alert(content)
              // console.log("我选中的文字:"+content)
            }
            else{
              hisstring=""
            }
      }
    //鼠标移动
    const mousemove=()=>{
            hasmove.value=true;
      }
    //鼠标点击
    const notsee = () => {
      //console.log('notsee function is called');
    };
    const see=()=>{
            visiblemenu.value = true;
            // selection.value="";
      }
    //滚轮滚动
    const hasscroll=()=>{
            visiblemenu.value = false;
            // window.getSelection().removeAllRanges()
      }
    const editorStore = useEditorStore()
     // 加载headings
    const loadHeadings = () => {
          const headings = [] as any[]
          if (!editor.value) return
          const transaction = editor.value.state.tr
          if (!transaction) return

          editor.value?.state.doc.descendants((node, pos) => {
            if (node.type.name === 'heading') {
              console.log(pos, node)
              const start = pos
              const end = pos + node.content.size
              // const end = pos + node
              const id = `heading-${headings.length + 1}`
              if (node.attrs.id !== id) {
                transaction?.setNodeMarkup(pos, undefined, {
                  ...node.attrs,
                  id
                })
              }

              headings.push({
                level: node.attrs.level,
                text: node.textContent,
                start,
                end,
                id
              })
            }
          })

          transaction?.setMeta('addToHistory', false)
          transaction?.setMeta('preventUpdate', true)

          editor.value?.view.dispatch(transaction)
          editorStore.setHeadings(headings)
      }
    // 使用ref创建可变的响应式引用
    // 编辑器初始化 用于创建编辑器实例。
    
    const editor = useEditor({
          content: ``,
          extensions: [
            Italic,
          StarterKit.configure({
              heading: {
                levels: [1, 2, 3,4,5],
              },
            }),
          
          Underline.configure({

          }),
          Highlight.configure({
            multicolor: true, // 允许使用多种颜色
          }),
          TextAlign.configure({
            types: ['heading', 'paragraph'],
            alignments: ['left', 'center', 'right'], // 添加所有需要的对齐方式,一开始没有写types这一行一直实现不了。
          }),
          
            TaskList,
            TaskItem,
            Placeholder.configure({//占位符
              placeholder: '请输入文本 …'
            }),
            OrderedList,
            BulletList,
            ListItem,
            CharacterCount.configure({
            limit: 10000
          })
      
          ],
          onUpdate({ edit }) {
            loadHeadings()
            editorStore.setEditorInstance(editor.value)
          },
          onCreate({ edit }) {
            loadHeadings()
            editorStore.setEditorInstance(editor.value)
          },
          injectCSS: false,

      });
      
  </script>
  <style>
  .EditMain{
    position: relative;
    width:100vw;
    height: 100vh;

    display: grid;
    grid-template-columns: 20% 60% 20%;
  
  }
  .lefttool {
    background-color: rgb(180,200,220);
    padding: 1rem;
    border-radius: 4px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .file-input {
    background-color: rgba(255,255,255,0.4);
    margin-bottom: 1rem;
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 1rem;
    width: 100%;
    max-width: 200px;
  }
  
  .image-preview {
    max-width: 100%;
    max-height: 500px; /* 可以根据需要调整高度 */
    object-fit: contain;
    margin-top: 1rem;
    border-radius: px;
  }
  .righttools{
    background-color: rgb(200, 230, 200);
    height: 100%;
    width: 100%;
  }
  .editor{
 
  }
  .editorcard{
    position: relative;
    width:95%;
    height: 95%;
    left: 2.5%;
    top:2.5%;
    display: grid;
    grid-template-rows: 5% 92% 3%;
    border: 1px solid #4f5c5765;
  }
  .editorcard .editor{
    position: relative;
    width:100%;
    height: 100%;
    left: 0;
    top:0;
    display: grid;
    grid-template-rows: 10% 90%;
  }
  .editorcard .editor{
    position: relative;
    width:100%;
    height: 100%;
    left: 0;
    top:0;
    display: grid;
    grid-template-rows: 10% 90%;
  }
  .toptools{
    background-color: rgba(207, 220, 245, 0.199);
    border-bottom: 1px dashed #9ca19f65;
  }
  .bottomcount{
    background-color: rgba(207, 220, 245, 0.199);
    border-top: 1px dashed #9ca19f65;
    height: 100%;
    width: 100%;
    display: grid;
    grid-template-columns: 100%;
    grid-template-rows: 100%;
    justify-items: center;
    align-items: center;
  }
  .editcont{
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
  </style>
  
  <style lang="scss">
  b {
    font-weight: bold;
  }
  
  .ProseMirror {
    overflow-y: scroll;
  }
  .ProseMirror p {
    margin: 0;
  }

  .ProseMirror:focus {
    outline: none;
  }
  .tiptap p.is-editor-empty:first-child::before {
    color: #adb5bd;
    content: attr(data-placeholder);
    float: left;
    height: 0;
    pointer-events: none;
  }
  
  .tiptap {
    > * + * {
      margin-top: 0.75em;
    }
  
    ul {
      padding: 0 2rem;
      list-style: square;
    }
    ol {
      padding: 0 2rem;
      list-style: decimal;
    }
    table {
      border-collapse: collapse;
      table-layout: fixed;
      width: 100%;
      margin: 0;
      overflow: hidden;
  
      td,
      th {
        min-width: 1em;
        border: 2px solid #ced4da;
        padding: 3px 5px;
        vertical-align: top;
        box-sizing: border-box;
        position: relative;
  
        > * {
          margin-bottom: 0;
        }
      }
  
      th {
        font-weight: bold;
        text-align: left;
        background-color: #f1f3f5;
      }
  
      .selectedCell:after {
        z-index: 2;
        position: absolute;
        content: '';
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background: rgba(200, 200, 255, 0.4);
        pointer-events: none;
      }
  
      .column-resize-handle {
        position: absolute;
        right: -2px;
        top: 0;
        bottom: -2px;
        width: 4px;
        background-color: #adf;
        pointer-events: none;
      }
  
      p {
        margin: 0;
      }
    }
    pre {
      background: #0d0d0d;
      color: #fff;
      font-family: 'JetBrainsMono', monospace;
      padding: 0.75rem 1rem;
      border-radius: 0.5rem;
  
      code {
        color: inherit;
        padding: 0;
        background: none;
        font-size: 0.8rem;
      }
  
      .hljs-comment,
      .hljs-quote {
        color: #616161;
      }
  
      .hljs-variable,
      .hljs-template-variable,
      .hljs-attribute,
      .hljs-tag,
      .hljs-name,
      .hljs-regexp,
      .hljs-link,
      .hljs-name,
      .hljs-selector-id,
      .hljs-selector-class {
        color: #f98181;
      }
      .hljs-number,
      .hljs-meta,
      .hljs-built_in,
      .hljs-builtin-name,
      .hljs-literal,
      .hljs-type,
      .hljs-params {
        color: #fbbc88;
      }
  
      .hljs-string,
      .hljs-symbol,
      .hljs-bullet {
        color: #b9f18d;
      }
  
      .hljs-title,
      .hljs-section {
        color: #faf594;
      }
  
      .hljs-keyword,
      .hljs-selector-tag {
        color: #70cff8;
      }
  
      .hljs-emphasis {
        font-style: italic;
      }
  
      .hljs-strong {
        font-weight: 700;
      }
    }
  }
  
  .tableWrapper {
    overflow-x: auto;
  }
  
  .resize-cursor {
    cursor: ew-resize;
    cursor: col-resize;
  }
  .contextmenu {
    width: 200px;
    margin: 0;
    background: #fff;
    z-index: 3000;
    position: absolute;
    list-style-type: none;
    padding:5px;
    padding-left: 15px;
    border-radius: 4px;
    font-size: 13px;
    font-weight: 400;
    color: #333;
    box-shadow: 1px 1px 2px 1px rgba(0, 0, 0, 0.3);
    display: flex;
  
    grid-template-columns:50% 50%;

  }
  .contextmenu .item {
      height: 35px;
      width:100%;
      line-height: 35px;
      
      color: rgb(29, 33, 41);
      cursor: pointer;
    }
    .contextmenu .item {
      height:35px;
      width:100%;
      line-height: 35px;
      color: rgb(29, 33, 41);
      cursor: pointer;
    }

    .contextmenu .item:hover {
      background: rgb(229, 230, 235);
    }
  </style>
