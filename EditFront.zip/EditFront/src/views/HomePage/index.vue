<template>
  <div class="mainbody">
    <h1 class="headtitle">首页</h1>
    <div>
      <h2 class="">{{ demoStore.helloPinia }}</h2>
    </div>

    <div class="uploadimage">
      <p class="commodity_img">
        <el-upload
          :on-success="handleSuccess"
          list-type="picture-card"
          :auto-upload="false"
          :on-change="handleChanges"
          :before-remove="beforeRemove"
          :on-preview="handlePictureCardPreview"
          :file-list="fileList"
          multiple
          limit="1"
          name="img"
        >
          <el-icon class="avatar-uploader-icon">
            <Plus />
          </el-icon>
        </el-upload>
      </p>

      <el-dialog v-model="dialogVisible">
        <img w-full class="imageshow" :src="dialogImageUrl" alt="Preview Image" />
      </el-dialog>
    </div>
    <el-button type="primary" @click="uploadimg">上传图片</el-button>

    <!-- 识别结果弹窗 -->
    <el-dialog v-model="resultDialogVisible" title="识别结果">
      <div>
        <h3>图片所含文字：</h3>
        <p>{{ ocrResult }}</p>
        <h4>信息真假性：</h4>
        <p>{{ isReal ? '可能为虚假信息' : '真实信息' }}</p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="resultDialogVisible = false">关闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { mainStore } from '../../store/index'
import { storeToRefs } from 'pinia'
import axios from 'axios'
import { ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Delete, Download, Plus, ZoomIn } from '@element-plus/icons-vue'
import type { UploadFile } from 'element-plus'

const demoStore = mainStore()
const { helloPinia } = storeToRefs(demoStore)

const dialogImageUrl = ref('')
const dialogVisible = ref(false)
const resultDialogVisible = ref(false) // 控制结果弹窗的显示与隐藏
const disabled = ref(false)
const ocrResult = ref('') // 识别结果
const isReal = ref(null) // 信息真假性

const handlePictureCardPreview = (file: UploadFile) => {
  dialogImageUrl.value = file.url!
  dialogVisible.value = true
}

const fileList = ref([])
const handleSuccess = () => {
  upload_btn.value = true
}
const handleChanges = img => {
  fileList.value.push(img)
  boxdisplay.value = 'hide_box'
}

const beforeRemove = () => {
  const result = new Promise((resolve, reject) => {
    ElMessageBox.confirm("此操作将删除该图片, 是否继续?", "提示", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning"
    })
      .then(() => {
        boxdisplay.value = "show_box"
        resolve()
        fileList.value = []
        upload_btn.value = false
      })
      .catch(() => {
        reject(false)
      })
  })
  return result
}

const uploadimg = () => {
  let formData = new FormData()
  formData.append("username", "12345")
  fileList.value.forEach(file => {
    formData.append("file", file.raw)
  })

  let url = 'http://127.0.0.1:5000/uploadimages'
  axios({
    method: 'post',
    url,
    data: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  }).then(res => {
    // 确保 res.data 存在
    if (res.data) {
      ocrResult.value = res.data.text || '无法识别图片中的文字'; // 提供一个默认值
      isReal.value = res.data.is_real !== null ? res.data.is_real : '无法判断真假性';
      resultDialogVisible.value = true; // 显示结果弹窗
      ElMessage({ message: '图片上传成功', type: 'success' });
    } 
    fileList.value = [];
    upload_btn.value = false;
  })
}
</script>

<style scoped>
.mainbody {
  position: relative;
  width: 100vw;
  height: 100vh;
  display: block;
}
.headtitle {
  filter: drop-shadow(0 0 2em #646cffaa);
  margin: 0;
}
</style>

<style lang="scss" scoped>
.mainbody {
  background: radial-gradient(circle, #f9f9f9, #3498db);
  position: relative;
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  top: 0px;
}
</style>

<style scoped>
.info-panel {
  background-color: #3498db;
  padding: 1rem;
  border-radius: 4px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  margin-bottom: 1rem;
}

.info-panel h3,
.info-panel h4 {
  margin-bottom: 0.5rem;
}

.info-panel p {
  margin-bottom: 0.5rem;
}
.hide_box {
  display: none;
}
.show_box {
  display: inline-flex;
}
.component {
  justify-content: center;
}

.imageshow {
  width: 100%;
  height: 100%;
  object-fit: fill;
}
</style>
