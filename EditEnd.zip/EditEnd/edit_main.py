from flask import Flask, json, request, jsonify
from flask_cors import CORS
import pymysql
DEBUG = True
app = Flask(__name__)
app.config.from_object(__name__)
CORS(app, resource={r'/*': {'origins': '*'}})
import erniebot

erniebot.api_type = 'aistudio'
@app.route('/')
def hello_world():
    return 'Hello, World!'
@app.route('/getpolish', methods=["GET", "POST"])
def getpolish():
    # 获取用户名
    username= request.form.get("username")
    # 获取用户的访问令牌
    key = request.form.get("key")
    # 获取用户提问内容
    quescont = request.form.get("cont")
    askcont="帮我润色下面这段话:"+quescont

    erniebot.access_token = key
    try:
        response = erniebot.ChatCompletion.create(
            model='ernie-bot',
            messages=[{'role': 'user', 'content':askcont}],
        )
        restext = response['result']
        webdict = {'answer': restext}
        return jsonify(webdict)
    except:
        return "error"

@app.route('/getcontinuation', methods=["GET", "POST"])
def getcontinuation():
    # 获取用户名
    username= request.form.get("username")
    # 获取用户的访问令牌
    key = request.form.get("key")
    # 获取用户提问内容
    quescont = request.form.get("cont")
    askcont="帮我续写下面这段话:"+quescont

    erniebot.access_token = key
    try:
        response = erniebot.ChatCompletion.create(
            model='ernie-bot',
            messages=[{'role': 'user', 'content':askcont}],
        )
        restext = response['result']
        webdict = {'answer': restext}
        return jsonify(webdict)
    except:
        return "error"
@app.route('/gettranslation', methods=["GET", "POST"])
def gettranslation():
    # 获取用户名
    username= request.form.get("username")
    # 获取用户的访问令牌
    key = request.form.get("key")
    # 获取用户提问内容
    quescont = request.form.get("cont")
    # print("我进入了trans")
    askcont="帮我翻译下面这段话（只需要输出翻译的结果）:"+quescont
    # Design A prompt for different tasks
    erniebot.access_token = key
    try:
        response = erniebot.ChatCompletion.create(
            model='ernie-bot',
            messages=[{'role': 'user', 'content':askcont}],
        )
        restext = response['result']
        webdict = {'answer': restext}
        return jsonify(webdict)
    except:
        return "error"

@app.route('/getKeyword_extraction', methods=["GET", "POST"])
def getKeyword_extraction():
    # 获取用户名
    username= request.form.get("username")
    # 获取用户的访问令牌
    key = request.form.get("key")
    # 获取用户提问内容
    quescont = request.form.get("cont")
    askcont="帮我提取语句中的关键词（只需要输出关键词）:"+quescont
    # Design A prompt for different tasks
    erniebot.access_token = key
    try:
        response = erniebot.ChatCompletion.create(
            model='ernie-bot',
            messages=[{'role': 'user', 'content':askcont}],
        )
        restext = response['result']
        webdict = {'answer': restext}
        return jsonify(webdict)
    except:
        return "error"
@app.route('/getSick_sentence_rewriting', methods=["GET", "POST"])
def getSick_sentence_rewriting():
    # 获取用户名
    username= request.form.get("username")
    # 获取用户的访问令牌
    key = request.form.get("key")
    # 获取用户提问内容
    quescont = request.form.get("cont")
    askcont="帮我修改这个病句（只需要输出修改后的正确句子）:"+quescont
    # Design A prompt for different tasks
    erniebot.access_token = key
    try:
        response = erniebot.ChatCompletion.create(
            model='ernie-bot',
            messages=[{'role': 'user', 'content':askcont}],
        )
        restext = response['result']
        webdict = {'answer': restext}
        return jsonify(webdict)
    except:
        return "error"
@app.route('/getsummary', methods=["GET", "POST"])
def getsummary():
    # 获取用户名
    username= request.form.get("username")
    # 获取用户的访问令牌
    key = request.form.get("key")
    # 获取用户提问内容
    quescont = request.form.get("cont")
    askcont="帮我生成这段话的摘要（只需要输出生成的摘要）:"+quescont
    # Design A prompt for different tasks
    erniebot.access_token = key
    try:
        response = erniebot.ChatCompletion.create(
            model='ernie-bot',
            messages=[{'role': 'user', 'content':askcont}],
        )
        restext = response['result']
        webdict = {'answer': restext}
        return jsonify(webdict)
    except:
        return "error"
if __name__ == '__main__':
    app.run(host="127.0.0.1", port=3389, debug=True)
