"""
    谣言检测模型:
        文本分词--->统计敏感词特征--->简易模型直接到这一步就行
        感情分析--->统计感情特征
        建决策树--->进行决策分类识别谣言
    @Author: Chen Zhang
    @Date: 2024/7/30
    @Email: HBU_ZhangChen@163.com
    两个地方需要修改:
        敏感词库: line42
        决策分析: line73
"""
# =============一些主观评价================ #
# ==========LTP库:哈工大开源真好用========== #
# ==========snownlp:只能说一坨============= #
# =======textblob:垃圾,只能英文,he~tui====== #
# ==Senta:没用过,百度开源,需要装PaddlePaddle== #
# =====NLTK:这位是textblob的亲爹,只能英文===== #
# ===cnsenti:专为国人开发,效果不错,respect!==== #
# ==使用cnsenti的时候不要看blog,直接看源码,易懂== #
# =================end====================== #
import torch
from ltp import LTP
import cnsenti
from cnsenti import Sentiment

# 统计敏感词出现的次数
def get_senstive_count(text):
    ltp = LTP("small")  # 加载 Small 模型，已挂载到本地
    # 将模型移动到 GPU 上
    if torch.cuda.is_available():
        # ltp.cuda()
        ltp.to("cuda")
    output = ltp.pipeline(text, tasks=["cws", "pos", "ner", "srl", "dep", "sdp"])
    # 使用字典格式作为返回结果
    seg_list = output.cws
    # print(seg_list)
    # ======================= #
    #     此处可以修改敏感词     #
    # ======================= #
    sensitive_words = ['人名', '地名']
    sensitive_count = 0
    for word in seg_list:
        if word in sensitive_words:
            sensitive_count += 1
    # print("敏感词一共出现:", sensitive_count)
    return sensitive_count

# 分析文本情感
def get_emotions(text):
    # 初始化情感分析器
    analyzer = Sentiment()
    # 使用cnsenti进行情感分析
    sentiment_result = analyzer.sentiment_calculate(text)
    pos_score = sentiment_result['pos']
    neg_score = sentiment_result['neg']

    return pos_score,neg_score

if __name__ == '__main__':
    text = input("请输入一段文本:")
    # 获取敏感词出现的次数
    sensitive_count = get_senstive_count(text)
    # 获取文本感情
    pos_score,neg_score = get_emotions(text)
    # 来一个类拉普拉斯平滑处理,防止分母为0
    pos_score += 1
    neg_score += 1
    # 消极程度
    neg = neg_score/pos_score

    # ==========根据情况自行修改=========== #
    #   sensitive_count:敏感词出现次数      #
    #   neg:消极程度与积极程度比值            #
    if sensitive_count>=1 or neg >=2:
        print(f"文本内容:{text}\n识别结果:不实")
    else:
        print(f"文本内容:{text}\n识别结果:真实")
