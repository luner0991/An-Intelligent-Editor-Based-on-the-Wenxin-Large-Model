from flask import Flask, json, request, jsonify
from flask_cors import CORS
import pymysql
import cv2
import numpy as np
import os
import paddle
from paddleocr import PaddleOCR, draw_ocr
import torch
from ltp import LTP
import cnsenti
from cnsenti import Sentiment
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
DEBUG = True
app = Flask(__name__)
app.config.from_object(__name__)
CORS(app, resource={r'/*': {'origins': '*'}})
ocr = PaddleOCR(use_angle_cls=True, lang="ch")  # need to run only once to download and load model into memory

def get_senstive_count(text):
    ltp = LTP("small")  # 加载 Small 模型，已挂载到本地
    # 将模型移动到 GPU 上
    if torch.cuda.is_available():
        # ltp.cuda()
        ltp.to("cuda")
    output = ltp.pipeline(text, tasks=["cws", "pos", "ner", "srl", "dep", "sdp"])
    # 使用字典格式作为返回结果
    seg_list = output.cws
    # print(seg_list)
    # ======================= #
    #     此处可以修改敏感词     #
    # ======================= #
    sensitive_words = ['人名', '地名','暴力','政府','色情']
    sensitive_count = 0
    for word in seg_list:
        if word in sensitive_words:
            sensitive_count += 1
    # print("敏感词一共出现:", sensitive_count)
    return sensitive_count

# 分析文本情感
def get_emotions(text):
    # 初始化情感分析器
    analyzer = Sentiment()
    # 使用cnsenti进行情感分析
    sentiment_result = analyzer.sentiment_calculate(text)
    pos_score = sentiment_result['pos']
    neg_score = sentiment_result['neg']
    return pos_score,neg_score

@app.route('/adduser', methods=['get', 'post'])
def adduser():
    username = request.form.get("username")
    password = request.form.get("password")
    print(username)
    print(password)
    return "已接收用户信息"

@app.route('/uploadimages', methods=['get', 'post'])
def uploadimages():
    username = request.form.get("username")
    img = request.files['file']
    picname = img.filename
    file = img.read()
    file = cv2.imdecode(np.frombuffer(file, np.uint8), cv2.IMREAD_COLOR)  # 解码为ndarray
    imgfile1_path = "./static/images/" + username + "/"

    if not os.path.exists(imgfile1_path):
        os.makedirs(imgfile1_path)
    img1_path = os.path.join(imgfile1_path, picname)
    cv2.imwrite(filename=img1_path, img=file)

    img_path = imgfile1_path + picname
    result = ocr.ocr(img_path, cls=True)

    text_output = ""
    for idx in range(len(result)):
        res = result[idx]
        for line in res:
            text_output += line[1][0] + " \n"  # line[1][0] is the text content
    text_output = text_output.strip()  # Remove any trailing whitespace
    print(text_output)
    # 获取敏感词出现的次数
    sensitive_count = get_senstive_count(text_output)
    # 获取文本感情
    pos_score, neg_score = get_emotions(text_output)
    # 来一个类拉普拉斯平滑处理,防止分母为0
    pos_score += 1
    neg_score += 1
    # 消极程度
    neg = neg_score / pos_score

    # ==========根据情况自行修改=========== #
    #   sensitive_count:敏感词出现次数      #
    #   neg:消极程度与积极程度比值            #
    if sensitive_count >= 1 or neg >= 2:
        is_real=1
        print(f"文本内容:{text_output}\n识别结果：可能为虚假信息")
    else:
        print(f"文本内容:{text_output}\n识别结果:真实信息")
        is_real=0


    url = "http://127.0.0.1:5000/static/images/" + username + "/" + picname
    print(url)

    conn = pymysql.connect(host='127.0.0.1', port=3306, user='root', password='root', charset='utf8')
    cursor = conn.cursor()
    conn.commit()
    cursor.execute('use editdata')
    sql = "INSERT INTO `imgpath` (`username`, `url`, `picname`) VALUES (%s, %s, %s);"
    cursor.execute(sql, (username, url, picname))
    conn.commit()
    cursor.close()
    conn.close()
    tempmap = {"url": url, "text": text_output, "is_real": is_real }#包含识别出的文字信息
    return jsonify(tempmap)

if __name__ == '__main__':
    app.run(host="127.0.0.1", port=5000, debug=True)

