import base64
import pathlib
import pprint

import requests

API_URL = "https://105b32tccaj145nd.aistudio-hub.baidu.com/ocr"
# 请前往 https://aistudio.baidu.com/index/accessToken 查看 访问令牌 并替换
TOKEN = "ee86cdb1c0c1bddf1ac5b46083ec4bc2002d2de0"

# 设置鉴权信息
headers = {
    "Authorization": f"token {TOKEN}",
    "Content-Type": "application/json"
}

# 对本地图片进行Base64编码
image_path = "./test.png"
image_bytes = pathlib.Path(image_path).read_bytes()
image_base64 = base64.b64encode(image_bytes).decode('ascii')

# 设置请求体
payload = {
    "image": image_base64  # Base64编码的文件内容或者文件链接
}

# 调用
resp = requests.post(url=API_URL, json=payload, headers=headers)

# 处理接口返回数据
assert resp.status_code == 200
result = resp.json()["result"]
output_image_path = "output.jpg"
with open(output_image_path, "wb") as f:
    f.write(base64.b64decode(result["image"]))
print(f"OCR结果图保存在 {output_image_path}")
print("\n文本信息:")
pprint.pp(result["texts"])